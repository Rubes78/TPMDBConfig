from flask import Flask, request, render_template
import os
from log import log

app = Flask(__name__)

CONFIG_FIELDS = [
    "API_URL",
    "API_TOKEN",
    "API_ID",
    "LOG_LEVEL",
    "BASE_DIR"
]

def create_connection():
    import pyodbc
    import configparser

    config = configparser.ConfigParser()
    ini_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "configuration.ini")
    config.read(ini_path)

    server = config.get("SQL", "server")
    database = config.get("SQL", "database")
    user = config.get("SQL", "username")
    password = config.get("SQL", "password")

    conn_str = (
        f"DRIVER={{ODBC Driver 18 for SQL Server}};"
        f"SERVER={server};DATABASE={database};UID={user};PWD={password};Encrypt=no;"
    )
    conn = pyodbc.connect(conn_str)
    return conn

@app.route("/", methods=["GET", "POST"])
def config_form():
    values = {}
    message = ""
    success = True

    try:
        conn = create_connection()
        cursor = conn.cursor()

        if request.method == "POST":
            for field in CONFIG_FIELDS:
                value = request.form.get(field, "")
                cursor.execute(
                    "UPDATE TPM_Config SET setting_value = ? WHERE setting_key = ?; "
                    "IF @@ROWCOUNT = 0 INSERT INTO TPM_Config (setting_key, setting_value) VALUES (?, ?);",
                    (value, field, field, value)
                )
            conn.commit()
            message = "Configuration updated."
            log("Web config updated successfully.")
        else:
            cursor.execute("SELECT setting_key, setting_value FROM TPM_Config")
            rows = cursor.fetchall()
            values = {row.setting_key: row.setting_value for row in rows}
            log(f"Loaded {len(values)} config value(s) from TPM_Config")

        cursor.close()
        conn.close()
    except Exception as e:
        message = "Error: " + str(e)
        log(message)
        success = False

    log(f"Request: {request.method} /")
    response = render_template("config_form.html", fields=CONFIG_FIELDS, values=values, message=message, success=success)
    log("Response: 200 OK")
    return response

if __name__ == "__main__":
    log(f"Launching config_web.py in background from: {os.path.abspath(__file__)}")
    import subprocess, sys
    if "--background" not in sys.argv:
        subprocess.Popen(["python3", os.path.abspath(__file__), "--background"],
                         stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL)
        sys.exit(0)
    else:
        log("Web config server starting silently in background")
        app.run(host="127.0.0.1", port=5050, debug=False)